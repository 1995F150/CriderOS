#!/usr/bin/env bash
# Runs inside the airootfs during ISO build — sets up the live environment.
set -euo pipefail

# --- Locale / time ---
sed -i 's/^#en_US.UTF-8/en_US.UTF-8/' /etc/locale.gen
locale-gen
echo 'LANG=en_US.UTF-8' > /etc/locale.conf

ln -sf /usr/share/zoneinfo/UTC /etc/localtime
hwclock --systohc 2>/dev/null || true

# --- Live user ---
useradd -m -G wheel,audio,video,storage,network,docker -s /bin/bash crider || true
echo 'crider:crideros' | chpasswd
echo 'root:crideros'   | chpasswd
echo '%wheel ALL=(ALL:ALL) NOPASSWD: ALL' > /etc/sudoers.d/10-crideros-wheel

# --- Services ---
systemctl enable NetworkManager.service
systemctl enable sddm.service
systemctl enable bluetooth.service
systemctl enable docker.service
systemctl set-default graphical.target

# --- SDDM theme ---
mkdir -p /etc/sddm.conf.d
cat > /etc/sddm.conf.d/10-crideros.conf <<'EOF'
[Theme]
Current=breeze
CursorTheme=breeze_cursors

[Autologin]
User=crider
Session=plasma.desktop
EOF

# --- Plasma defaults: dark theme + green accent ---
mkdir -p /home/crider/.config
cat > /home/crider/.config/kdeglobals <<'EOF'
[General]
ColorScheme=BreezeDark
Name=Breeze Dark

[KDE]
LookAndFeelPackage=org.kde.breezedark.desktop

[Icons]
Theme=breeze-dark
EOF
chown -R crider:crider /home/crider

# --- First-boot welcome ---
cat > /usr/local/bin/crideros-firstboot <<'EOF'
#!/usr/bin/env bash
notify-send "Welcome to CriderOS" "Run 'calamares' from the menu to install. Default password: crideros"
EOF
chmod +x /usr/local/bin/crideros-firstboot

mkdir -p /home/crider/.config/autostart
cat > /home/crider/.config/autostart/crideros-firstboot.desktop <<'EOF'
[Desktop Entry]
Type=Application
Exec=/usr/local/bin/crideros-firstboot
Hidden=false
NoDisplay=false
Name=CriderOS Welcome
EOF
chown -R crider:crider /home/crider/.config

echo "[crideros] airootfs customization complete."
