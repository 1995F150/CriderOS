#!/usr/bin/env bash
# Build CriderOS ISO inside an Arch Linux Docker container.
# Works on any host with Docker (Linux, macOS, Windows/WSL2).
#
# Output: out/crideros-<version>-x86_64.iso
set -euo pipefail

VERSION="${VERSION:-0.1}"
ARCH="x86_64"
PROFILE_DIR="$(cd "$(dirname "$0")/.." && pwd)/archiso"
OUT_DIR="$(cd "$(dirname "$0")/.." && pwd)/out"
WORK_DIR="$(cd "$(dirname "$0")/.." && pwd)/.work"

mkdir -p "$OUT_DIR" "$WORK_DIR"

echo "==> Building CriderOS ${VERSION} (${ARCH})"
echo "    profile: ${PROFILE_DIR}"
echo "    output:  ${OUT_DIR}"

docker run --rm --privileged \
  -v "${PROFILE_DIR}:/profile:ro" \
  -v "${OUT_DIR}:/out" \
  -v "${WORK_DIR}:/work" \
  -e VERSION="${VERSION}" \
  archlinux:latest \
  bash -c '
    set -euo pipefail
    pacman -Sy --noconfirm --needed archiso
    cp -r /profile /tmp/profile
    mkarchiso -v -w /work -o /out /tmp/profile
  '

# Generate SHA256 for releases
ISO_PATH=$(ls -1t "${OUT_DIR}"/*.iso | head -n1)
( cd "${OUT_DIR}" && sha256sum "$(basename "${ISO_PATH}")" > "$(basename "${ISO_PATH}").sha256" )

echo ""
echo "==> Done."
echo "    ISO:    ${ISO_PATH}"
echo "    SHA256: ${ISO_PATH}.sha256"
