# CriderOS brand palette

Use these everywhere — wallpapers, SDDM theme, GRUB splash, Plasma color scheme,
website, marketing.

| Role           | HSL                    | Hex       | Notes |
|----------------|------------------------|-----------|-------|
| Field Green    | `hsl(142, 55%, 21%)`   | `#1a5d34` | Primary brand color (wheat field, FFA roots) |
| Deep Soil      | `hsl(140, 65%, 14%)`   | `#0d3b1f` | Headlines, GRUB background |
| Harvest Gold   | `hsl(40,  90%, 55%)`   | `#f3b93a` | Accent — buttons, highlights |
| Barn Red       | `hsl(8,   70%, 45%)`   | `#c54530` | Destructive / warning |
| Bone           | `hsl(40,  35%, 95%)`   | `#f6f1e6` | Light text on dark backgrounds |
| Dusk           | `hsl(220, 15%, 12%)`   | `#191c22` | Dark UI background |

All colors stored as HSL so they map cleanly into Tailwind tokens
(see `cridergpt.com` `index.css`) and KDE color schemes.
